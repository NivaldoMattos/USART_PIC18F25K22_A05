//------------------------------------------------------------------------------
// File Name:USART1
// By: N.M
// Estudo da USART do PIC18F25K22
// Data:27/07/2019
// Por: Nivaldo Mattos
// uLab Eletr�nica
// email: ulabchannel@gmail.com 
// 
//------------------------------------------------------------------------------
#include "mcc_generated_files/mcc.h"
//------------------------------------------------------------------------------
void main(void)
{
    // Initialize the device
    SYSTEM_Initialize();

    // If using interrupts in PIC18 High/Low Priority Mode you need to enable the Global High and Low Interrupts
    // If using interrupts in PIC Mid-Range Compatibility Mode you need to enable the Global and Peripheral Interrupts
    // Use the following macros to:

    // Enable the Global Interrupts
   INTERRUPT_GlobalInterruptEnable();

    // Disable the Global Interrupts
    //INTERRUPT_GlobalInterruptDisable();

    // Enable the Peripheral Interrupts
    INTERRUPT_PeripheralInterruptEnable();

    // Disable the Peripheral Interrupts
    //INTERRUPT_PeripheralInterruptDisable();

    uint8_t cont;
    while (1)
    {
        // Add your application code
        for(cont=0;cont<100;cont++) //1seg
            __delay_ms(10);
        
        // putch('a');
        printf("Bem vindos ao uLab Eletronica!\n");
    }
}
//------------------------------------------------------------------------------
// Rotina de recepcao da USART1
// Eh chamada sempre que chega um caracter pela serial
// Baudrate:9600bps
//------------------------------------------------------------------------------
void Usart1Main(uint8_t rcvByte)
{
   if(rcvByte=='a')
        LED_AZ_Toggle();
   else if(rcvByte=='b')
        LED_VM_Toggle();
   else if(rcvByte=='c')
        LED_AM_Toggle();
}
//------------------------------------------------------------------------------
// End of File
//------------------------------------------------------------------------------
